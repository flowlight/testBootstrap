<div id="conditions" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="Conditions Générale" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="conditionsLabel">Conditions Générales</h3>
  </div>
  <div class="modal-body">
    <small>
      <?php include 'conditions_text.php' ?>
    </small>
  </div>
  
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">Fermer</button>
    <a class="btn" href="conditions_print.php">Imprimer</a>
  </div>
</div>