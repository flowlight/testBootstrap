<head>
    <title>Côté Jardin - City Break - Sartrouville</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- FONT -->
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic,900italic" rel="stylesheet" type="text/css">
    
    <!-- BOOTSTRAP -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/bootstrap-responsive.css" rel="stylesheet" media="screen">
    
    <!-- STYLE -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- GALLERY -->
    <link rel="stylesheet" href="css/bootstrap-image-gallery.min.css">

    <!-- DATE PICKER -->
    <link href="css/datepicker.css" rel="stylesheet"> 

    <!-- ICONS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">

</head>